package com.ruoyi.teach.controller;

import com.ruoyi.common.core.controller.TeachBaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.teach.domain.entity.FalldownDevice;
import com.ruoyi.teach.service.IFalldownDeviceService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/device/falldowndevice")
public class FalldownDeviceController extends TeachBaseController {

    private final IFalldownDeviceService falldownDeviceService;

    @GetMapping("/list")
    public AjaxResult list(
            @RequestParam(value = "DeviceCode", required = false) String deviceCode,
            @RequestParam(value = "Model", required = false) String model,
            @RequestParam(value = "Status", required = false) String status,
            @RequestParam(value = "pageNum", required = false) Integer pageNum,
            @RequestParam(value = "pageSize", required = false) Integer pageSize
    ) {
        startPage(pageNum, pageSize);
        return getPagedData(
                falldownDeviceService.findByConditions(deviceCode, model, status, pageNum, pageSize),
                pageNum == null ? 1 : pageNum,
                pageSize == null ? 10 : pageSize
        );
    }

    @GetMapping("/detail")
    public AjaxResult detail(@RequestParam("Id") Long id) {
        return success(falldownDeviceService.selectDeviceById(id));
    }

    @PostMapping("/add")
    public AjaxResult add(@RequestBody FalldownDevice device) {
        return toAjax(falldownDeviceService.insertDevice(device));
    }

    @PostMapping("/update")
    public AjaxResult update(@RequestBody FalldownDevice device) {
        return toAjax(falldownDeviceService.updateDevice(device));
    }

    @PostMapping("/delete")
    public AjaxResult delete(@RequestBody Long[] ids) {
        if (ids == null || ids.length == 0) {
            return error("请选择要删除的数据");
        }
        return toAjax(falldownDeviceService.deleteDeviceByIds(Arrays.asList(ids)));
    }

}
