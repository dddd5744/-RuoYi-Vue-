package com.ruoyi.teach.service.impl;

import com.ruoyi.teach.domain.entity.FalldownDevice;
import com.ruoyi.teach.mapper.FalldownDeviceMapper;
import com.ruoyi.teach.service.IFalldownDeviceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Date;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FalldownDeviceServiceImpl implements IFalldownDeviceService {

    private final FalldownDeviceMapper falldownDeviceMapper;

    @Override
    public List<FalldownDevice> findByConditions(String deviceCode, String model, String status, Integer pageNum, Integer pageSize) {
        if (pageNum == null || pageSize == null) {
            return Collections.emptyList();
        }
        return falldownDeviceMapper.findByConditions(deviceCode, model, status, pageNum, pageSize);
    }

    @Override
    public FalldownDevice selectDeviceById(Long id) {
        return falldownDeviceMapper.selectDeviceById(id);
    }

    @Override
    public int insertDevice(FalldownDevice device) {
        device.setCreateTime(new Date());
        return falldownDeviceMapper.insertDevice(device);
    }

    @Override
    public int updateDevice(FalldownDevice device) {
        device.setUpdateTime(new Date());
        return falldownDeviceMapper.updateDevice(device);
    }

    @Override
    public int deleteDeviceByIds(List<Long> ids) {
        return falldownDeviceMapper.deleteDeviceByIds(ids);
    }
}
