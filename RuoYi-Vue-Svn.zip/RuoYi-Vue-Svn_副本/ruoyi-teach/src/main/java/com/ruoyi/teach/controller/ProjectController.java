package com.ruoyi.teach.controller;

import com.ruoyi.common.core.controller.TeachBaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.teach.domain.entity.TeachProjectInfo;
import com.ruoyi.teach.service.ITeachProjectInfoService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequiredArgsConstructor
@RequestMapping("/research/project")
public class ProjectController extends TeachBaseController {

    private final ITeachProjectInfoService teachProjectInfoService;

    @GetMapping("/list")
    public AjaxResult list(
            @RequestParam(value = "ProjectName", required = false) String prjName,
            @RequestParam(value = "Leader", required = false) String manager,
            @RequestParam(value = "Status", required = false) String prjStatus,
            @RequestParam(value = "pageNum", required = false) Integer pageNum,
            @RequestParam(value = "pageSize", required = false) Integer pageSize
    ) {
        startPage(pageNum, pageSize);
        return getPagedData(
                teachProjectInfoService.selectProjectList(prjName, manager, prjStatus, pageNum, pageSize),
                pageNum == null ? 1 : pageNum,
                pageSize == null ? 10 : pageSize
        );
    }

    @GetMapping("/detail")
    public AjaxResult detail(@RequestParam("Id") Integer id) {
        return success(teachProjectInfoService.selectProjectById(id));
    }

    @PostMapping("/add")
    public AjaxResult add(@RequestBody TeachProjectInfo projectInfo) {
        return toAjax(teachProjectInfoService.insertProject(projectInfo));
    }

    @PostMapping("/update")
    public AjaxResult update(@RequestBody TeachProjectInfo projectInfo) {
        return toAjax(teachProjectInfoService.updateProject(projectInfo));
    }

    @PostMapping("/delete")
    public AjaxResult delete(@RequestBody String ids) {
        if (ids == null || ids.trim().isEmpty()) {
            return error("请选择要删除的数据");
        }
        // 前端可能发送数组 "[1,2,3]" 或纯字符串 "1,2,3"
        String idStr = ids.trim();
        if (idStr.startsWith("[") && idStr.endsWith("]")) {
            idStr = idStr.substring(1, idStr.length() - 1);
        }
        if (idStr.isEmpty()) {
            return error("请选择要删除的数据");
        }
        List<Integer> idList = Arrays.stream(idStr.split(","))
                .map(String::trim)
                .filter(item -> !item.isEmpty())
                .map(Integer::valueOf)
                .collect(Collectors.toList());
        return toAjax(teachProjectInfoService.deleteProjectByIds(idList));
    }
}
