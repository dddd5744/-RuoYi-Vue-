package com.ruoyi.teach.service;

import com.ruoyi.teach.domain.entity.TeachProjectInfo;

import java.util.List;

public interface ITeachProjectInfoService {

    List<TeachProjectInfo> selectProjectList(
            String prjName,
            String manager,
            String prjStatus,
            Integer pageNum,
            Integer pageSize
    );

    TeachProjectInfo selectProjectById(Integer id);

    int insertProject(TeachProjectInfo projectInfo);

    int updateProject(TeachProjectInfo projectInfo);

    int deleteProjectByIds(List<Integer> ids);
}
