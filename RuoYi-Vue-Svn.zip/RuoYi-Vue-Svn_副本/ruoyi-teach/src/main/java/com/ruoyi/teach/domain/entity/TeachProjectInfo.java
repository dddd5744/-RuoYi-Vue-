package com.ruoyi.teach.domain.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class TeachProjectInfo implements Serializable {

    @JsonProperty("Id")
    private Integer id;

    @JsonProperty("ProjectName")
    private String prjName;

    @JsonProperty("ProjectCode")
    private String prjCode;

    /** 项目类别，如"国家级""省级"等 */
    @JsonProperty("Category")
    private String prjType;

    @JsonProperty("Status")
    private String prjStatus;

    @JsonProperty("PrjDesc")
    private String prjDesc;

    @JsonProperty("StartDate")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date startDate;

    @JsonProperty("EndDate")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date endDate;

    /** 负责人 */
    @JsonProperty("Leader")
    private String manager;

    /** 经费(万元) */
    @JsonProperty("Funding")
    private Double money;

    @JsonProperty("Remark")
    private String remark;

    @JsonProperty("CreateBy")
    private String createBy;

    @JsonProperty("UpdateBy")
    private String updateBy;

    @JsonProperty("CreateTime")
    private Date createTime;

    @JsonProperty("UpdateTime")
    private Date updateTime;

    @JsonProperty("DeleteTime")
    private Date deleteTime;

}
