package com.ruoyi.teach.service;

import com.ruoyi.teach.domain.entity.FalldownDevice;

import java.util.List;

public interface IFalldownDeviceService {

    List<FalldownDevice> findByConditions(
            String deviceCode,
            String model,
            String status,
            Integer pageNum,
            Integer pageSize
    );

    FalldownDevice selectDeviceById(Long id);

    int insertDevice(FalldownDevice device);

    int updateDevice(FalldownDevice device);

    int deleteDeviceByIds(List<Long> ids);

}
