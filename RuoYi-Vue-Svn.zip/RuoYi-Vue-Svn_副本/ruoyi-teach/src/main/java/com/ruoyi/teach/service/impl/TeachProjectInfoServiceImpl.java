package com.ruoyi.teach.service.impl;

import com.ruoyi.teach.domain.entity.TeachProjectInfo;
import com.ruoyi.teach.mapper.TeachProjectInfoMapper;
import com.ruoyi.teach.service.ITeachProjectInfoService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Date;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TeachProjectInfoServiceImpl implements ITeachProjectInfoService {

    private final TeachProjectInfoMapper teachProjectInfoMapper;

    @Override
    public List<TeachProjectInfo> selectProjectList(
            String prjName,
            String manager,
            String prjStatus,
            Integer pageNum,
            Integer pageSize) {
        if (pageNum == null || pageSize == null) {
            return Collections.emptyList();
        }
        return teachProjectInfoMapper.selectProjectList(prjName, manager, prjStatus);
    }

    @Override
    public TeachProjectInfo selectProjectById(Integer id) {
        return teachProjectInfoMapper.selectProjectById(id);
    }

    @Override
    public int insertProject(TeachProjectInfo projectInfo) {
        projectInfo.setCreateTime(new Date());
        return teachProjectInfoMapper.insertProject(projectInfo);
    }

    @Override
    public int updateProject(TeachProjectInfo projectInfo) {
        projectInfo.setUpdateTime(new Date());
        return teachProjectInfoMapper.updateProject(projectInfo);
    }

    @Override
    public int deleteProjectByIds(List<Integer> ids) {
        return teachProjectInfoMapper.deleteProjectByIds(ids);
    }
}
