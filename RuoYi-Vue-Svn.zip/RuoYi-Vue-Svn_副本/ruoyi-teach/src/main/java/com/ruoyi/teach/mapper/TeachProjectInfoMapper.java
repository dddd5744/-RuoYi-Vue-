package com.ruoyi.teach.mapper;

import com.ruoyi.teach.domain.entity.TeachProjectInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface TeachProjectInfoMapper {

    List<TeachProjectInfo> selectProjectList(
            @Param("prjName") String prjName,
            @Param("manager") String manager,
            @Param("prjStatus") String prjStatus
    );

    TeachProjectInfo selectProjectById(@Param("id") Integer id);

    int insertProject(TeachProjectInfo projectInfo);

    int updateProject(TeachProjectInfo projectInfo);

    int deleteProjectByIds(@Param("ids") List<Integer> ids);
}
