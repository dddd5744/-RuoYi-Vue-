package com.ruoyi.teach.controller;

import com.ruoyi.common.core.controller.TeachBaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.system.domain.SysPost;
import com.ruoyi.system.service.ISysPostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/device/jiaobanzhuang")
public class JiaobanzhuangController extends TeachBaseController {

    @Autowired
    private ISysPostService postService;

    @GetMapping("/list")
    public AjaxResult list(
            @RequestParam(value = "postCode", required = false) String postCode,
            @RequestParam(value = "postName", required = false) String postName,
            @RequestParam(value = "status", required = false) String status,
            @RequestParam(value = "pageNum", required = false) Integer pageNum,
            @RequestParam(value = "pageSize", required = false) Integer pageSize
    ) {
        SysPost query = new SysPost();
        query.setPostCode(postCode);
        query.setPostName(postName);
        query.setStatus(status);
        startPage(pageNum, pageSize);
        List<SysPost> list = postService.selectPostList(query);
        return getPagedData(list, pageNum == null ? 1 : pageNum, pageSize == null ? 10 : pageSize);
    }

    @GetMapping("/detail")
    public AjaxResult detail(@RequestParam("postId") Long postId) {
        return success(postService.selectPostById(postId));
    }

    @PostMapping("/add")
    public AjaxResult add(@RequestBody SysPost post) {
        return toAjax(postService.insertPost(post));
    }

    @PostMapping("/update")
    public AjaxResult update(@RequestBody SysPost post) {
        return toAjax(postService.updatePost(post));
    }

    @PostMapping("/delete")
    public AjaxResult delete(@RequestBody Long[] postIds) {
        if (postIds == null || postIds.length == 0) {
            return error("请选择要删除的数据");
        }
        return toAjax(postService.deletePostByIds(postIds));
    }
}
